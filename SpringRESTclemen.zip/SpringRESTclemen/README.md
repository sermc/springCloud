### Api REST con CRUD


    * API REST ejemlo CRUD Ejercicio 5 Spring REST  
    * http://localhost:8081/api/clientes
    * Base de datos H2 en memoria
    * En resources se encuentra una coleccion para Postman.